How to run the Fuel Delivery Management System (fdondms) Project

1. Download the  zip file

2. Extract the file and copy fdondms folder

3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)

4. Open PHPMyAdmin (http://localhost/phpmyadmin)

5. Create a database with name fdondmsdb

6. Import fdondmsdb.sql file(given inside the zip package in SQL file folder)

7.Run the script http://localhost/fdondms (frontend)



Credential for admin panel :

Username: admin
Password: Test@123

Credential for Fuel Station owner panel :

Username: john12
Password: Test@123
 Or Register a new owner.

Credential for  User panel :

Username: rahul12
Password: Test@123

 Or Register a new User.